class exceptions {
  String message;
  exceptions(this.message);
}
